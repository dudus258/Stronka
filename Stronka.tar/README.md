# Stronka
 Musimy to ogarnąć
